### Crash Report Server

#### HTTP Server的实现

```python
import BaseHTTPServer
class CrashReportHTTPRequestHandler(BaseHTTPServer.BaseHTTPRequestHandler):
	"""
	一个带有 GET/HEAD/POST 命令的简单 HTTP 请求处理程序。
	这个程序从当前目录及其任何子目录中提供文件。文件的 MIME 类型由调用 .guess_type() 方法来确定。	 并且可以接收客户端上传的文件。
	GET/HEAD/POST 请求是相同的，唯一的区别在于 HEAD 请求省略了文件的实际内容
	"""
	server_version = "CrashReportHTTPServer/" + __version__
  
    def do_GET(self):
        """ Serve a GET request. """
        ret_file = self.send_head()
        if ret_file:
            self.copyfile(ret_file, self.wfile)
            ret_file.close()
    def do_HEAD(self):
        """ Serve a HEAD request. """
        ret_file = self.send_head()
        if ret_file:
            ret_file.close()
     
    def do_POST(self):
        """ Serve a POST request."""
        thread_name =  threading.currentThread().getName()
        print "[****************** thread name: %s **********************]  " % (thread_name)
        print "--- receive a POST request from: ", self.address_string(), self.client_address
  
        ret, info = self.handle_post_data()
        if not ret:
            print "--- post data error: ", info
        else:
            print "--- post data OK: ", info
        reply_file = StringIO()
        request_path = self.translate_path(self.path)
        link_css = '<link rel="stylesheet" href="%s" type="text/css">' % os.path.relpath(DEFAULT_CSS_PATH, request_path)
        reply_file.write('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">')
        reply_file.write(link_css)
        reply_file.write("<html>\n<title>Upload Result Page</title>\n")
        reply_file.write("<body>\n<h2>Upload Result Page</h2>\n")
        reply_file.write("<hr>\n")
        if ret:
            reply_file.write("<strong>Success:</strong>")
        else:
            reply_file.write("<strong>Failed:</strong>")
        reply_file.write(info)
        reply_file.write("</body>\n</html>\n")
        length = reply_file.tell()
        reply_file.seek(0)
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.send_header("Content-Length", str(length))
        self.end_headers()
        if reply_file:
            self.copyfile(reply_file, self.wfile)
            reply_file.close()
        if ret:
            if self.product == "GuiStatReport":
                self.get_stat_report()
            else:
                cr_ret, cr_info = self.get_crash_report()
                if cr_ret:
                    print "--- generate report OK: ", cr_info
                    self.save_report_to_db()
                else:
                    print "--- generate report error: ", cr_info
      
    def send_head(self):
        """ Common code for GET and HEAD commands.
        This sends the response code and MIME headers.
        Return value is either a file object (which has to be copied
        to the outputfile by the caller unless the command was HEAD,
        and must be closed by the caller under all circumstances), or
        None, in which case the caller has nothing further to do.
        """
        path = self.translate_path(self.path)
        ret_file = None
        if os.path.isdir(path):
            if not self.path.endswith('/'):
                # redirect browser - doing basically what apache does
                self.send_response(301)
                self.send_header("Location", self.path + "/")
                self.end_headers()
                return None
            for index in "index.html", "index.htm":
                index = os.path.join(path, index)
                if os.path.exists(index):
                    path = index
                    break
            else:
                return self.list_directory(path)
        ctype = self.guess_type(path)
        try:
            # Always read in binary mode. Opening files in text mode may cause
            # newline translations, making the actual size of the content
            # transmitted *less* than the content-length!
            ret_file = open(path, 'rb')
        except IOError:
            self.send_error(404, "File not found")
            return None
        self.send_response(200)
        self.send_header("Content-type", ctype)
        fs = os.fstat(ret_file.fileno())
        self.send_header("Content-Length", str(fs[6]))
        self.send_header("Last-Modified", self.date_time_string(fs.st_mtime))
        self.end_headers()
        return ret_file
```

```python
class ThreadedHTTPServer(ThreadingMixIn, BaseHTTPServer.HTTPServer):
    """ Handle requests in a separate thread. """
    pass
     
def main():
     
    # single thread
    #httpd = BaseHTTPServer.HTTPServer(SERVER_ADDR, CrashReportHTTPRequestHandler)
     
    # muti thread
    httpd = ThreadedHTTPServer(SERVER_ADDR , CrashReportHTTPRequestHandler)
     
    httpd.serve_forever()
```

#### mini dump文件上传

```shell
POST / HTTP/1.1
User-Agent: Breakpad/1.0 (Linux)
Host: 192.168.58.104:4000
Accept: */*
Content-Length: 519
Content-Type: multipart/form-data; boundary=----------------------------8beb3ececf3b
 
 
------------------------------8beb3ececf3b
Content-Disposition: form-data; name="prod"
 
 
tflexgui@#@hostname:bcnode001,user name:tanli
,comment:123,module:LMC
------------------------------8beb3ececf3b
Content-Disposition: form-data; name="ver"
 
 
2013.09.00rc1.
------------------------------8beb3ececf3b
Content-Disposition: form-data; name="upload_file_minidump"; filename="aa.tflex.2013.09.00rc1..dump"
Content-Type: application/octet-stream
 
 
hello, woroldl
 
 
------------------------------8beb3ececf3b--
```

```python
# 处理post数据，包括crash report相关信息和文件
    def handle_post_data(self):
        boundary = self.headers.plisttext.split("=")[1]
        remain_bytes = int(self.headers['content-length']) # 解析请求中的边界值，并初始化剩余字节数
        
        # http post command, using multpart/form-data format
        # 1. read boundary
        line = self.rfile.readline()
        remain_bytes -= len(line)
        if not boundary in line:
            return (False, "Content does not begin with boundary")
        
        # 2. read "prod" field
        line = self.rfile.readline()
        remain_bytes -= len(line)
        print "--- field name: ", line
        
        # 3. read empty line
        line = self.rfile.readline()
        remain_bytes -= len(line)
        
        # 4. read "prod" field value
        line = self.rfile.readline()
        remain_bytes -= len(line)
        print "--- field value: ", line
        line = line.replace('appTflex', 'tflexgui', 1);
        line = line.replace('tachyonRTE', 'appGDSEditor', 1);
        if line.startswith('tflexgui@#@'):
            self.comment = line[(len('tflexgui@#@')):]
            self.product = 'tflexgui\r\n'
        elif line.startswith('appGDSEditor@#@'):
            self.comment = line[(len('appGDSEditor@#@')):]
            self.product = 'appGDSEditor\r\n'
        elif line.startswith('FakeCrashApp@#@'):
            self.comment = line[(len('FakeCrashApp@#@')):]
            self.product = 'FakeCrashApp\r\n'
        elif line.startswith('GuiStatReport@#@'):
            self.comment = line[(len('GuiStatReport@#@')):]
            self.product = 'GuiStatReport\r\n'
        elif line.startswith('.gds2server@#@'):
            self.comment = line[(len('.gds2server@#@')):]
            self.product = '.gds2server\r\n'
        elif line.startswith('pwegui@#@'):
            self.comment = line[(len('pwegui@#@')):]
            self.product = 'pwegui\r\n'
        else:
            self.comment = "hostname:web,user name:web,comment:,module:\r\n";
            self.product = line;

        # for feature adding client time
        self.comment = self.comment.replace('@#@',',client time:', 1)
        self.product = self.product[0:-2]
        self.comment = self.comment[0:-2]
        print "--- product: ", self.product
        print "--- comment: ", self.comment
        
        # 5. read boundary 
        line = self.rfile.readline()
        remain_bytes -= len(line)
        
        # 6. read "ver" field
        line = self.rfile.readline()
        remain_bytes -= len(line)
        print "--- field name: ", line
        
        # 7. read empty line
        line = self.rfile.readline()
        remain_bytes -= len(line)
    
        # 8. read "ver" field value
        line = self.rfile.readline()
        remain_bytes -= len(line)
        self.version = line
        self.version = self.version[0:-2]
        print "--- version: ", self.version
        self.release_version = util.get_release_version(self.version)
        print "--- release_version: ", self.release_version
        
        # 9. read boundary 
        line = self.rfile.readline()
        remain_bytes -= len(line)
        
        # 10. read "upload_file_minidump" field
        line = self.rfile.readline()
        remain_bytes -= len(line)
        print "--- field name: ", line
        
        file_name = re.findall(r'Content-Disposition.*name="upload_file_minidump"; filename="(.*)"', line)
        if not file_name:
            return (False, "Can't find out file name...")
        file_name = file_name[0].replace('\\','/')
        file_name = os.path.basename(file_name)
        self.is_tar_file = False;
        if file_name.endswith('.tar.gz'):
            self.is_tar_file = True;
        
        if self.comment.startswith('hostname:web,user name:web'):
            self.product, self.version = util.get_product_version_from_report_name(file_name)
            print "--- for web upload, product: ", self.product
            print "--- for web upload, version: ", self.version
            self.release_version = util.get_release_version(self.version)
            print "--- for web upload, release_version: ", self.release_version
        
        received_dir = os.path.join(SERVER_PATH
            , "dmp"
            , self.product
            , self.version);
        if not os.path.exists(received_dir):
            os.mkdir(received_dir)
        dump_file_path = os.path.join(received_dir, file_name)
        while os.path.exists(dump_file_path):
            dump_file_path += "_"
        self.dump_file_path = dump_file_path;
        
        # 11. read "Content-Type" 
        line = self.rfile.readline()
        remain_bytes -= len(line)
        print "--- content type: ", line
        # 12. read empty line
        line = self.rfile.readline()
        remain_bytes -= len(line)
        
        try:
            out = open(self.dump_file_path, 'wb')
        except IOError:
            return (False, "Can't create file to write")
        print "--- receive file %s to %s " % (file_name, self.dump_file_path)
        
        # 13. read file content
        preline = self.rfile.readline()
        remain_bytes -= len(preline)
        while remain_bytes > 0:
            line = self.rfile.readline()
            remain_bytes -= len(line)
            if boundary in line:
                preline = preline[0:-1]
                if preline.endswith('\r'):
                    preline = preline[0:-1]
                out.write(preline)
                out.close()
                return (True, "File '%s' upload successfully!" % file_name)
            else:
                out.write(preline)
                preline = line
        return (False, "Unexpected ends of data.")
```

### Python2 to Python3

注释部分是py2写法

```python
# import BaseHTTPServer  
import http.server

# import commands
import subprocess
# status, output = commands.getstatusoutput(cmd)
status, output = subprocess.getstatusoutput(cmd)

# import urlparse
from urllib.parse import urlparse

# from SocketServer import ThreadingMixIn
from socketserver import ThreadingMixIn

# try:
#     from cStringIO import StringIO
# except ImportError:
#     from StringIO import StringIO

try:
    from io import BytesIO as StringIO
except ImportError:
    from io import StringIO
    
# from urllib import urlopen
from urllib.request import urlopen

# except Exception, e:
except Exception as e:
    
# argspec = inspect.getargspec(receiver)
# 获取函数或方法的参数规范（返回一个包含参数名称、默认参数值、可变位置参数和可变关键字参数等信息的命名元组）
argspec = inspect.signature(receiver) 

# def __init__(self, col, source=None, is_summary=False, condition=None, **extra):
#  super(SqlAggregate,self).__init__(col, source, is_summary, **extra)
#  self.condition = condition
# super()方法通常用于在子类中调用父类的方法，以便在子类中扩展或修改父类的行为，python2中，super()方法需要显式传递当前类和实例作为参数，例如super(classname,self).__init__(...)；python3中不需要传递类名和实例，因为会被隐式传递，所以可以简化
def __init__(self, col, source=None, is_summary=False, condition=None, **extra):
    super().__init__(col, source, is_summary, **extra)
    self.condition = condition

# python3的sorted()函数不支持cmp参数，只支持key参数
sorted(iterable,key=None,reverse=False)
# iterable – 可迭代对象
# key – 主要是用来进行比较的元素，只有一个参数，具体的函数的参数就是取自于可迭代对象中，指定可迭代对象中的一个元素来进行排序。
# reverse – 排序规则，reverse = True 降序 ， reverse = False 升序（默认）

# python range函数原型
range(start, stop[, step])
# start默认为0，包含在范围内；stop不包含在范围内；step默认为1
```

### Rewrite by golang

table:

- issuereport_issue查询的结果显示在/issues
  - 0|id|integer|1||1
    1|product|varchar(64)|1||0
    2|version|varchar(128)|1||0
    3|module|varchar(64)|1||0
    4|function|varchar(128)|1||0
    5|status|varchar(64)|0|'New'|0
    6|assignee|varchar(32)|0|NULL|0
    7|ticket|varchar(64)|0|NULL|0
    8|changelist|varchar(64)|0|NULL|0
    9|rootcause|varchar(512)|0|NULL|0
    10|description|varchar(512)|0|NULL|0
    11|onereportfile|varchar(512)|1||0
    12|callstack|varchar(1024)|0|NULL|0

- issuereport_report查询的结果显示在/reports
  - 0|id|integer|1||1
    1|issue_id|integer|0|NULL|0
    2|timestamp|datetime|1||0
    3|product|varchar(64)|1||0
    4|version|varchar(128)|1||0
    5|host|varchar(64)|0|NULL|0
    6|user|varchar(64)|0|NULL|0
    7|comment|varchar(1024)|0|NULL|0
    8|module|varchar(64)|0|NULL|0
    9|signal|varchar(64)|0|NULL|0
    10|function|varchar(128)|0|NULL|0
    11|file|varchar(256)|0|NULL|0
    12|line|varchar(64)|0|NULL|0
    13|reportfile|varchar(512)|1||0
    14|clienttime|datetime|0|NULL|0
    15|callstack|varchar(1024)|0|NULL|0
- issuereport_statreport
  - 0|id|integer|1||1
    1|product|varchar(64)|1||0
    2|version|varchar(128)|1||0
    3|releaseversion|varchar(128)|1||0
    4|host|varchar(64)|0|NULL|0
    5|user|varchar(64)|0|NULL|0
    6|comment|varchar(1024)|0|NULL|0
    7|otherdes|varchar(1024)|0|NULL|0
    8|clienttime|datetime|0|NULL|0
    9|statfile|varchar(512)|1||0
- django_content_type
  - 0|id|integer|1||1
    1|name|varchar(100)|1||0
    2|app_label|varchar(100)|1||0
    3|model|varchar(100)|1||0

### weasy_preview code reading

/domain:

```go
type Issue struct {
	ID        int
	Name      string `binding:"required" gorm:"<-create;uniqueIndex:uidx_issue;default:'';not null"`
	Owners    []User `gorm:"many2many:issue_owners;<-:false;constraint:OnDelete:CASCADE"`
	CreatedAt time.Time
	Product   string   `gorm:"default:'';not null"`
	Version   string   `gorm:"default:'';not null"`
	Function  string   `gorm:"default:'';not null"`
	Reports   []Report `gorm:"many2many:issue_reports;<-:false;constraint:OnDelete:CASCADE"`
	ModuleID  *int
	Module    *Module `gorm:"<-:false"`
	Status    Status  `gorm:"default:0;not null"`
	Assignee  string  `gorm:"default:'';not null"`
	Ticket    string  `gorm:"default:'';not null"`

	/// Customize here
}
// binding:required指定为必填项，使用gorm标签指定了在创建时使用默认值为空字符串，设定了uidx_issue的唯一索引
// many2many关联，表示多对多的关系
```

